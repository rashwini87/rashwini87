print("AWS Re/Start is an amazing program!")
print(" Hi, I am excited, happy, and overwhelmed.")