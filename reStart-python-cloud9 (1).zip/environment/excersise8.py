
print("programming is amazing!")
print(" Hello, i feel curious, inspired, and amazed.")