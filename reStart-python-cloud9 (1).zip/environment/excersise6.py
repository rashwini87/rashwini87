string1 = "ashwini"
print(string1)
string2 = "aws student"
print(string2)
string =string1 + string2
print (string)