name = input("what is your fav colour ")
age = input("which is your birth month ")
print("{},. fav colour {} {}!".format(colour,month))





