name = input("What is your name?  ")
age = input("What is your age?  ")
print("{}, is {} years old!".format(name,age))

