glass_of_water=3
print("i drank " +str(glass_of_water) + " glasses of water today.")
