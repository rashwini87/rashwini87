Integer=9
print(str(Integer) + " is data type " + str(type(Integer)))
Float=12.34
print(str(Float) + " is data type " + str(type(Float)))
Complex=9j
print(str(Complex) + " is data type " + str(type(Complex)))
Bool= False
print(str(Bool) + "is data type " + str(type(Bool)))

