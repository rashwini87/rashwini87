myValue=5
print(myValue)
myVar=10
print(myVar)
print(int(myVar) + int(myValue))

